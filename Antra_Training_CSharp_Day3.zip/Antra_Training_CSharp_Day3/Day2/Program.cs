﻿// See https://aka.ms/new-console-template for more information

using Day2;

Customer c=new Customer(1,"sai","sai@gmail.com");
Console.WriteLine(c.CustomerName);

FullTimeEmployee f= new FullTimeEmployee(id:1);
f.PerformWork();
PartTimeEmployee p=new PartTimeEmployee(id:3);  
p.PerformWork();
Manager m=new Manager(id:2);
m.AttendMeeting();

//Addition a=new Addition();
//a.AddNumber(1,3);

//static one
//no need intialization
Addition.AddNumber(1,2);


int a=10;
int b = 100;
Console.WriteLine(ExtensionMethod.EvenOrAdd(a));

Console.WriteLine(a.EvenOrAdd());


//Employee Repository
//EmployeeRepository rep=new EmployeeRepository();
//rep.AddEmployee(new Employee(1,"sai","sai@gmail.com"));