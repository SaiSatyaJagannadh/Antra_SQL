namespace Day2;

public class EmployeeRepository
{
    private  List<Employee> employees = new List<Employee>();

    public bool AddEmployee(Employee employee)
    {
        employees.Add(employee);
        return true;
    }
}