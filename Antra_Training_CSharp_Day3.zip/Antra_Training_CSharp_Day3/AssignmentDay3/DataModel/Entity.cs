//Q3

namespace AssignmentDay3.DataModel;

public class Entity
{
    public int Id { get; set; }
}