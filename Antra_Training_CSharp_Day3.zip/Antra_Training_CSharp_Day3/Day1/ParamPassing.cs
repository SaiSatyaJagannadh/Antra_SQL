namespace Day1;

public class ParamPassing
{
    //pass by value 
    public void PassByValue(int a, int b)
    {
        a = 100;
        b = 200;
        Console.WriteLine($"inside passing in parampassing {a} {b}");
    }
    
    //pass by reference 
    public void PassByValue(ref int a,ref int b)
    {
        a = 100;
        b = 200;
        Console.WriteLine($"inside passing in parampassing ref {a} {b}");
    }


    public void AreaOfCircle(int radius, double pi = 3.14)
    {
        Console.WriteLine($"area of circle  {pi*radius*radius}");
    }

    public bool IsAuthentic(string username, string password, out string str)
    {
        if (username == "admin" && password == "admin")
        {
            str="successfully logged in";
            return true;
        }
        else
        {
            str = "failed to login";
            return false;

        }
    }
    
    [Obsolete]//this keyword means this method will be replaced with better one 
    
    public int AddIntegers(int a, int b)
    {
        return a + b;
    }
    public int AddIntegersUnlimited(params int[] arr)
    {
        int sum = 0;
        //implement for loop for multiple adding like
        for (int i = 0; i < arr.Length; i++)
        {
            sum += arr[i];
        }
        return sum;
    }
    
    
}