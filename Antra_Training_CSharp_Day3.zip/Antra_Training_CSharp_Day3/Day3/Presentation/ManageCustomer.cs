using Day3.DataModel;
using Day3.Repositories;
namespace Day3.Presentation;

public class ManageCustomer
{
 private CustomerRepository customerRepository = new CustomerRepository();

 private void AddCustomer()
 {
  Customer customer = new Customer();
  Console.WriteLine("Enter ID-->");
  customer.Id = Convert.ToInt32(Console.ReadLine());
  Console.WriteLine("Enter Name-->");
  customer.Name = Console.ReadLine();
  Console.WriteLine("Enter Email-->");
  customer.Email= Console.ReadLine();

  if (customerRepository.Insert(customer) == 1)
  {
   Console.WriteLine("Customer created");
  }
  else
  {
   Console.WriteLine("Customer not created");
  }
 }

 private void PrintAllCustomers()
 {
  List<Customer> customers = customerRepository.GetAll();
  foreach (var customer in customers)
  {
   Console.WriteLine(customer.Id + "\t" + customer.Name + "\t" + customer.Email);
  }
 }
 
 private void DeleteCustomer()
 {
  Console.WriteLine("Enter ID-->");
  int id = Convert.ToInt32(Console.ReadLine());
  if (customerRepository.Delete(id) == 1)
  {
   Console.WriteLine("Customer deleted");
  }
  else
  {
   Console.WriteLine("Customer not deleted");
  }
 }
//for running 
 public void Run()
 {
  Console.Clear();
  Console.WriteLine("Press 1 to Add");
  Console.WriteLine("Press 2 to Print All");
  Console.WriteLine("Press 3 to Delete");
  Console.WriteLine("Press 4 to Exit");
  Console.WriteLine("ENter the Choice===>");
  int choice = Convert.ToInt32(Console.ReadLine());
  while (choice != 4)
  {
   switch (choice)
   {
    case 1:
     AddCustomer();
     break;
    case 2:
     PrintAllCustomers();
     break;
    case 3:
     DeleteCustomer();
     break;
    default:
     Console.WriteLine("Incorrect choice");
     break;
   }
   Console.WriteLine("Press number to continue");
   choice = Convert.ToInt32(Console.ReadLine());
  }
 }
}