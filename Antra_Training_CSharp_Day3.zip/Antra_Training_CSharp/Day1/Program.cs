﻿// See https://aka.ms/new-console-template for more information

// double b = 10.686767;
// Console.WriteLine(b);
//
// float c= 3.5687f;
// Console.WriteLine(c);
//
// decimal d=3.45m;
// Console.WriteLine(d);
//
// string s = "hello";
// bool flag = true;
// Console.WriteLine($"the value of  is {d}");


using System.Text;
using Day1;

string s= null;
int? price =null; // int price=null; this wont work

StringBuilder ss=new StringBuilder("saisatya"); // string is immutable 
ss[0]='J'; // but we can change it to mutable by doing stringbuilder
Console.WriteLine(ss);

//why we need enum
int mor=1;
int eve=3;
int aft=2;

int tiemofday=3;
if (tiemofday == eve)
{
    
    Console.WriteLine("eveng time");
}

//enum

TimeOfDay d=TimeOfDay.aft;
Console.WriteLine(d);

//pass by value 
ParamPassing pp=new ParamPassing();
int x = 300;
int y = 400;
Console.WriteLine($"before inside passing  {x} {y}");
pp.PassByValue(x,y);
Console.WriteLine($"after inside passing {x} {y}");

Console.WriteLine("---------------------------");

//pass by reference
Console.WriteLine($"before inside passing  {x} {y}");
pp.PassByValue(ref x, ref y);
Console.WriteLine($"after inside passing {x} {y}");


pp.AreaOfCircle(radius:4);
pp.AreaOfCircle(radius:4, pi:2);

string str;
pp.IsAuthentic("king", "admin",out str);
Console.WriteLine(str);

//for implementing the addintegers
Console.WriteLine(pp.AddIntegersUnlimited(10,20,20,90));