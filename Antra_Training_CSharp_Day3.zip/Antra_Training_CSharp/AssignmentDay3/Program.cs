﻿// See https://aka.ms/new-console-template for more information

using AssignmentDay3;
using AssignmentDay3.Presentation;
using AssignmentDay3.Repository;


//Q1
/*Stack<int> stack = new Stack<int>();
stack.Push(10);
stack.Push(20);
Console.WriteLine("Stack count: " + stack.Count());
Console.WriteLine("Popped: " + stack.Pop());
Console.WriteLine("Stack count after pop: " + stack.Count());*/


//Q2
ManageMyList m = new ManageMyList();
m.Run();

//Q3
/*ManageMyListTwo mm=new ManageMyListTwo();
mm.Run();*/