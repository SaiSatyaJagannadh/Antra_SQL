namespace Day2;

public static class ExtensionMethod
{
    public static string EvenOrAdd(this int number)
    {
        if (number % 2 == 0)
        {
            return "Even";
        }
        else
        {
            return "Odd";
        }
    }
}