namespace Day2;

public class Addition
{
    //Method Overloading
    //static no need to create instance we can directly do it
    //like this Addition.AddNumber(1,2);
    public static int AddNumber(int num1, int num2)
    {
        return num1 + num2;
    }
    public static int AddNumber(int num1, int num2, int num3)
    {
        return num1 + num2+num3;
    }
    public static double AddNumber(double num1, int num2)
    {
        return num1 + num2;
    }
    /*public double AddNumber(double num1, int num2)
    {
        return num1 + num2;
    }*/
}