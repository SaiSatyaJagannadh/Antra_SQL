namespace Day3.Repositories;

public interface IRepository<T>  where T: class
{
    //CRUD 
    int Insert(T item);
    int Update(T item);
    int Delete(int Id);
    
    List <T> GetAll();
    T GetById(int Id);
    
}