using Day3.DataModel;

namespace Day3.Repositories;

public class ProductRepository: IRepository<Product>
{
    public int Insert(Product item)
    {
        throw new NotImplementedException();
    }

    public int Update(Product item)
    {
        throw new NotImplementedException();
    }

    public int Delete(int Id)
    {
        throw new NotImplementedException();
    }

    public List<Product> GetAll()
    {
        throw new NotImplementedException();
    }

    public Product GetById(int Id)
    {
        throw new NotImplementedException();
    }
}