namespace Day3.DataModel;

public class Employee
{
    
}