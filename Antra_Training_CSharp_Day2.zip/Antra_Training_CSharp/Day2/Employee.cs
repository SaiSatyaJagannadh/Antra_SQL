namespace Day2;

public abstract class Employee
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public string Phone { get; set; }
    public string Address { get; set; }

    //base class constructor
    public Employee(int id)
    {
        id = id;
    }
        
    
    /*public virtual void PerformWork()
    {
        
    }*/

    //for abstarct 
    public abstract void PerformWork();
}

public class FullTimeEmployee : Employee
{
    public FullTimeEmployee(int id) : base(id)

    {
        
    }
    public decimal BiweeklyPay { get; set; }
    public string Benefits { get; set; }

    public override void PerformWork()
    {
        Console.WriteLine("Full time employee");
    }
}

//no one can inherit sealed class
public sealed class PartTimeEmployee : Employee
{
    public PartTimeEmployee(int id) : base(id)
    {
        
    }
    public decimal Hourly { get; set; }

    public override void PerformWork()
    {
        Console.WriteLine("Part time employee");
    }
}
//methods don't be implemented but constructors need to be done 
public class Manager : FullTimeEmployee
{

    public Manager(int id) : base(id)
    {
        
    }
public decimal Bonus { get; set; }
public  void AttendMeeting()
{
    Console.WriteLine("Manager Meeting");
}
}