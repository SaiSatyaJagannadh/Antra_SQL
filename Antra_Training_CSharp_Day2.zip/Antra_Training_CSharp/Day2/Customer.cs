namespace Day2;

public class Customer
{

    public Customer(int id, string name, string email)

    {
        id = id;
        name = name;
        email = email;
    }
    /*private string CustomerName;

    public string CustomerName
    {
        get
        {
            return CustomerName;
        }
        set
        {
            CustomerName = value;
        }
    }
    */
    
    //auto implemented property above code can be written like this
    //get set method used for encapsulation
    
    public string CustomerName { get; set; }
}