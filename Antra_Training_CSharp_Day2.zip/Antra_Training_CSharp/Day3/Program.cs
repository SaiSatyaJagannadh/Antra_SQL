﻿// See https://aka.ms/new-console-template for more information

using Day3;
using Day3.Presentation;

/*
Console.WriteLine(GenericDemo.AreEqual(12,34));
Console.WriteLine(GenericDemo.AreEqual(12.32,34.89));
Console.WriteLine(GenericDemo.AreEqual("Hello", "Hello"));
*/

// comparing here wrong cast by using object
//Console.WriteLine(GenericDemo.AreEqual("Hello", 89));

//Generic method at method level 
/*
Console.WriteLine(GenericDemo.AreEqual<string>("Hello", "Hello"));
Console.WriteLine(GenericDemo.AreEqual<string>("Hello", "12"));
*/


//Generic with class level
//Console.WriteLine(GenericDemo<string>.AreEqual("Hello", "Hello"));

ManageCustomer m = new ManageCustomer();
m.Run();

//without adding different names like overloadingh we will use this
//builder.Services.AddScoped(<IRepostiory<Customer>, CustomerRepository2);

//Dictionary<int, string> dictionary = new Dictionary<int, string>();