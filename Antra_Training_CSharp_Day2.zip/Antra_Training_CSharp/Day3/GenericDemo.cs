namespace Day3;


//static main use for creating generic 
//Implementing the Generic class level 
public static class GenericDemo<T>
{
   
   //for every time we need to create overloading for differet comaprison

   /*public static bool AreEqual(int a, int b)
   {
      return a.Equals(b);
   }
   public static bool AreEqual(double a, double b)
   {
      return a.Equals(b);
   }*/

   //object type 
   /*public static bool AreEqual(object obj1, object obj2)
   {
      return obj1.Equals(obj2);
   }*/
   
   public static bool AreEqual(T obj1, T obj2)
   {
      return obj1.Equals(obj2);
   }
}