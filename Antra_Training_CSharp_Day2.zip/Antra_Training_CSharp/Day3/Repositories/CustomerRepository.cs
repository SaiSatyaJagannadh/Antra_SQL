
using Day3.DataModel;

namespace Day3.Repositories;

public class CustomerRepository: IRepository<Customer>
{
    //creating this to store the data here 
    private List<Customer> customers = new List<Customer>();
    
    public int Insert(Customer item)
    {
        if (GetById(item.Id) == null)
        {
            customers.Add(item);

            return 1;

        }
        else
        {
            return 0;
        }
    }

    public int Update(Customer item)
    {
        Customer customer = GetById(item.Id);
        if (item.Name != null)
        {
            customer.Id = item.Id;
            customer.Email=item.Email;
            customer.Name = item.Name;
            return 1;
        }
        else
        {
            return 0;
        }
    }

    public int Delete(int Id)
    {
        Customer customer = GetById(Id);
        if (customer != null)
        {
            customers.Remove(customer);
            return 1;
        }
        else
        {
            return 0;
        }
        
    }

    public List<Customer> GetAll()
    {
        return customers;

    }

    public Customer GetById(int Id)
    {
        for (int i = 0; i < customers.Count; i++)
        {
            if (customers[i].Id == Id)
            {
                return customers[i];
            }
            
        }
        return null;
    }
}