namespace Day1;

public enum TimeOfDay
{
    //enum used for specific values 
    mon, 
    aft, 
    eveng
}

